import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../App.css";
import { PutLeaveById } from "../Services/HttpLeave";

const EditLeave = () => {
  const [formData, setFormData] = useState({
    leaveId: "",
    employeeId: "",
    userId: "",
    name: "",
    email: "",
    manager: "",
    fromDate: "",
    toDate: "",
    totalLeaveDays: 0,
    leaveReason: "",
    leaveStatus: "",
  });
  const [error, setError] = useState("");
  const [totalLeaveDays, setTotalLeaveDays] = useState(0);
  const [isEditable, setIsEditable] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  const leave = location.state?.leave;

  useEffect(() => {
    if (leave) {
      const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString("en-CA"); 
      };

      setFormData({
        leaveId: leave.leaveId,
        employeeId: leave.employeeId,
        userId: leave.userId,
        name: leave.name,
        email: leave.email,
        manager: leave.manager,
        fromDate: formatDate(leave.fromDate), 
        toDate: formatDate(leave.toDate), 
        totalLeaveDays: leave.totalLeaveDays,
        leaveReason: leave.leaveReason,
        leaveStatus: leave.leaveStatus,
      });
      setTotalLeaveDays(leave.totalLeaveDays);

      if (leave.leaveStatus === "Approved" || leave.leaveStatus === "Rejected") {
        setIsEditable(false);
      }
    } else {
      setError("No leave data found.");
    }
  }, [leave]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === "fromDate" || name === "toDate") {
      const fromDate = name === "fromDate" ? new Date(value) : new Date(formData.fromDate);
      const toDate = name === "toDate" ? new Date(value) : new Date(formData.toDate);

      if (fromDate && toDate && toDate >= fromDate) {
        const diffTime = Math.abs(toDate - fromDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        setTotalLeaveDays(diffDays);
      } else {
        setTotalLeaveDays(0);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isEditable) {
      setError("This leave cannot be edited because it is already Approved or Rejected.");
      return;
    }

    const token = localStorage.getItem("authToken");

    const updatedLeaveData = {
      ...formData,
      totalLeaveDays,
      fromDate: new Date(formData.fromDate).toISOString(),
      toDate: new Date(formData.toDate).toISOString(),
    };

    try {


      const response = await PutLeaveById(formData.leaveId, updatedLeaveData);

      if (!response.ok) {
        throw new Error("Failed to update leave.");
      }

      alert("Leave updated successfully.");
      navigate("/getempleaves");
    } catch (error) {
      setError(`Error updating leave: ${error.message}`);
    }
  };

  return (
    <div className="new-leave-container">
      <h1>Edit Leave</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit} className="new-leave-form">
        <div className="form-group">
          <label>Name</label>
          <input type="text" value={formData.name} disabled />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" value={formData.email} disabled />
        </div>
        <div className="form-group">
          <label>Manager</label>
          <input type="text" value={formData.manager} disabled />
        </div>
        <div className="form-group">
          <label>From Date</label>
          <input
            type="date"
            name="fromDate"
            value={formData.fromDate}
            onChange={handleChange}
            disabled={!isEditable}
          />
        </div>
        <div className="form-group">
          <label>To Date</label>
          <input
            type="date"
            name="toDate"
            value={formData.toDate}
            onChange={handleChange}
            disabled={!isEditable}
          />
        </div>
        <div className="form-group">
          <label>Total Leave Days</label>
          <input type="number" value={totalLeaveDays} disabled />
        </div>
        <div className="form-group">
          <label>Leave Reason</label>
          <textarea
            name="leaveReason"
            value={formData.leaveReason}
            onChange={handleChange}
            disabled={!isEditable}
          />
        </div>
        {isEditable && (
          <button type="submit">Save Changes</button>
        )}
      </form>
      {!isEditable && <p>This leave record cannot be edited.</p>}
    </div>
  );
};

export default EditLeave;