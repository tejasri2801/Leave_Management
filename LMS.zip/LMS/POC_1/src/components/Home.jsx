import React from 'react';
import '../App.css';
import { useSelector } from 'react-redux';

function HomePage() {

    const isLoggedIn = useSelector(state => state.isLoggedIn);
  return (
    <div>
      <h1>Welcome to Leave Management System</h1>
      <p>{isLoggedIn ? 'Click Login to Sign in to your Account' : 'Go to Dashboard for your records'}</p> 
    </div>
  );
}

export default HomePage;
