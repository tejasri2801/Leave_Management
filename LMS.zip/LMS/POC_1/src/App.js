import './App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import RootLayout from './components/Root';
import HomePage from './components/Home';
import RegistrationPage from './components/Registration';
import LoginPage from './components/Login';
import NewLeave from './components/NewLeave';
import GetEmployeeLeaves from './components/GetEmployeeLeaves';
import GetManagerLeavesPage from './components/GetManagerLeaves';
import EditLeave from './components/EditLeave';

const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      { path: '/', element: <HomePage /> },
      { path: '/register', element: <RegistrationPage /> },
      { path: '/login', element: <LoginPage /> },
      { path: '/newleave', element: <NewLeave /> },
      { path: '/getempleaves', element: <GetEmployeeLeaves /> },
      { path: '/editleave', element: <EditLeave /> },
      { path: '/getmanleaves', element: <GetManagerLeavesPage /> },
    ],
  },
]);

function App() {
  return (
    <RouterProvider router={router} />
  );
}

export default App;
