const getToken = () => {
    return localStorage.getItem("authToken");
};

export const PutLeaveById = async (id, updatedLeaveData) => {
    const token = getToken(); 
    const response = await fetch(`https://localhost:7040/api/Leave/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, 
        },
        body: JSON.stringify(updatedLeaveData),
    });

    return response;
};

export const GetAllLeaves = async () => {
    const token = getToken(); 
    const response = await fetch(`https://localhost:7040/api/Leave/user`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, 
        },
    });

    return response;
};

export const GetLeavesOfManager = async (managerName) => {
    const token = getToken(); 
    const response = await fetch(
        `https://localhost:7040/api/Leave/manager/${managerName}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`, 
            'Content-Type': 'application/json',
          },
        }
    );

    return response;
};

export const UserLogin = async (email, password) => {
    const response = await fetch('https://localhost:7040/api/User/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userEmail: email, password: password }),
    });

    return response;
};

export const PostLeave = async (leaveData) => {
    const token = getToken(); 
    const response = await fetch('https://localhost:7040/api/Leave', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`, 
        },
        body: JSON.stringify(leaveData),
    });

    return response;
};

export const PostUser = async (userName, email, password, role) => {
    const response = await fetch('https://localhost:7040/api/User', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: 0, userName, email, password, role }),
    });

    return response;
};

export const DeleteLeave = async (id) => {
    const token = getToken(); 
    const response = await fetch(`https://localhost:7040/api/Leave/${id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, 
        },
    });

    return response;
};

export const UpdateStatusOfLeave = async (leaveId, newStatus) => {
    const token = getToken(); 
    const response = await fetch(
        `https://localhost:7040/api/Leave/update-status/${leaveId}?status=${newStatus}`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`, 
            'Content-Type': 'application/json',
          },
        }
    );

    return response;
};
