import { createSlice } from '@reduxjs/toolkit';

const getToken = () => {
  return localStorage.getItem('authToken');
};

const initialState = {
  isLoggedIn: !!getToken(),
  token: getToken(),
  userId: 0,
}; 

const reduxSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setIsLogin: (state) => {
      state.isLoggedIn = !state.isLoggedIn;
    },
    login: (state, action) => {
      state.isLoggedIn = true;
      state.token = action.payload.token;
      localStorage.setItem('authToken', action.payload.token); 
    }, 
    logout: (state) => {
      state.isLoggedIn = false;
      state.token = null;
      state.userId = 0;
      localStorage.removeItem('authToken');
    },
    setUserId: (state, action) => {
      state.userId = action.payload;
    },
  }, 
});

export const { login, logout, setUserId, setIsLogin } = reduxSlice.actions;
export default reduxSlice.reducer;
