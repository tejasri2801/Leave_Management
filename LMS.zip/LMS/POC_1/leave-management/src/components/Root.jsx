import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import '../App.css';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../store/ReduxSlice';
import logo from '../logo.svg';

function RootLayout() {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector(state=> state.auth.isLoggedIn);
  console.log(isLoggedIn);

  const handleLogout = () => {
    dispatch(logout());
    localStorage.removeItem('authToken');
    window.location.href = '/login';
  };

  return (
    <div>
      <header>
        <nav>
          <div>
            <img src={logo} alt="Logo" />
          </div>
          <ul>
            <li><Link to="/">Home</Link></li>
            {isLoggedIn ? (
              <li><button className='logout-button' onClick={handleLogout}>Logout</button></li>
            ) : (
              <li><Link to="/login">Login</Link></li>
            )}
          </ul>
        </nav>
      </header>

      <main>
        <Outlet />
      </main>
    </div>
  );
}

export default RootLayout;
