import React, { useState, useEffect } from 'react';
import '../App.css';
import { useNavigate } from 'react-router-dom';
import { GetLeavesOfManager, UpdateStatusOfLeave } from '../Services/HttpLeave';

function GetManagerLeavesPage() {
  const [leaves, setLeaves] = useState([]);
  const [notification, setNotification] = useState(''); 
  const navigate = useNavigate();
  const managerName = localStorage.getItem('userName');
  const token = localStorage.getItem('authToken');

  const fetchLeaves = async () => {
    const managerName = localStorage.getItem('userName');
    const token = localStorage.getItem('authToken');
    if (!token || !managerName) {
      navigate('/login');
      return;
    }

    const normalizedManagerName = managerName.toLowerCase();

    try {
      const response = await GetLeavesOfManager(normalizedManagerName);

      if (response.ok) {
        const data = await response.json();
        setLeaves(data); 
      } else {
        setLeaves([]);  
      }
    } catch (err) {
      setLeaves([]);  
    }
  };

  useEffect(() => {
    fetchLeaves();
  }, [navigate]);

  const handleUpdateStatus = async (leaveId, newStatus) => {
    const updatedLeaves = leaves.map(leave => {
      if (leave.leaveId === leaveId) {
        return { ...leave, leaveStatus: newStatus }; 
      }
      return leave;
    });
    setLeaves(updatedLeaves); 

    try {
      const response = await UpdateStatusOfLeave(leaveId, newStatus);

      if (response.ok) {
        setNotification(`${newStatus} Successfully`);  
        fetchLeaves(); 
      } else {
        setLeaves(updatedLeaves); 
        setNotification('Failed to update leave status.');
      }
    } catch (err) {
      setLeaves(updatedLeaves); 
      setNotification('An error occurred while updating leave status.');
    }

    setTimeout(() => {
      setNotification('');
    }, 3000);
  };

  return (
    <div className="manager-leaves-container">
      <h2>Leave Requests for Manager: {managerName}</h2>

      {notification && <div className="notification">{notification}</div>}

      <table className="leaves-table">
        <thead>
          <tr>
            <th>Leave ID</th>
            <th>Employee ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>From Date</th>
            <th>To Date</th>
            <th>Total Days</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {leaves.length === 0 ? (
            <tr>
              <td colSpan="10" style={{ textAlign: 'center' }}>No leave requests found.</td>
            </tr>
          ) : (
            leaves.map((leave) => (
              <tr key={leave.leaveId}>
                <td>{leave.leaveId}</td>
                <td>{leave.employeeId}</td>
                <td>{leave.name}</td>
                <td>{leave.email}</td>
                <td>{new Date(leave.fromDate).toLocaleDateString()}</td>
                <td>{new Date(leave.toDate).toLocaleDateString()}</td>
                <td>{leave.totalLeaveDays}</td>
                <td>{leave.leaveReason}</td>
                <td>{leave.leaveStatus}</td>
                <td>
                  {leave.leaveStatus === 'Pending' && (
                    <>
                      <button
                        className="approve-button"
                        onClick={() => handleUpdateStatus(leave.leaveId, 'Approved')}
                      >
                        Approve
                      </button>
                      <button
                        className="reject-button"
                        onClick={() => handleUpdateStatus(leave.leaveId, 'Rejected')}
                      >
                        Reject
                      </button>
                    </>
                  )}

                  {leave.leaveStatus === 'Approved' && (
                    <button className="approved-button" disabled>
                      Approved
                    </button>
                  )}

                  {leave.leaveStatus === 'Rejected' && (
                    <button className="rejected-button" disabled>
                      Rejected
                    </button>
                  )}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default GetManagerLeavesPage;
