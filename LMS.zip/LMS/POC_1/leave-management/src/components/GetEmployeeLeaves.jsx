import React, { useEffect, useState } from "react";
import "../App.css";
import { Link, useNavigate } from "react-router-dom";
import { DeleteLeave, GetAllLeaves } from "../Services/HttpLeave";
import { useSelector } from "react-redux";

const GetEmployeeLeaves = () => {
  const [leaves, setLeaves] = useState([]);
  const [error, setError] = useState(null);
  //const [userId, setUserId] = useState(null); 
  const token = localStorage.getItem("authToken");
  const navigate = useNavigate();
  //const userId = useSelector(state => state.userId);
  const userId = localStorage.getItem("userId");


  console.log(userId);

  useEffect(() => {
    if (!token) {
      setError("User is not authenticated. Please log in.");
      navigate("/");  
      return;
    }

  }, [token, navigate]);

  useEffect(() => {
    if (!userId) return;

    const fetchLeaves = async () => {
      try {
        const response = await GetAllLeaves(userId);

        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log(data);
        setLeaves(data);
      } catch (err) {
        setError(`Failed to fetch leave records: ${err.message}`);
      }
    };

    fetchLeaves();
  }, [userId, token]);

  const handleNavigateToApplyLeave = () => {
    navigate("/newleave"); 
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Approved":
        return "approved";  
      case "Rejected":
        return "rejected"; 
      case "Pending":
        return "pending";  
      default:
        return "";
    }
  };

  // const handleEdit = (leave) => {
  //   navigate("/editleave", { state: { leave } });
  // };

  const handleDelete = (leaveId) => {
    if (window.confirm("Are you sure you want to delete this leave record?")) {
      const token = localStorage.getItem("authToken");

      const deleteLeave = async () => {
        try {
          const response = await DeleteLeave(leaveId);

          if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
          }

          setLeaves((prevLeaves) => prevLeaves.filter((leave) => leave.leaveId !== leaveId));
          alert("Leave record deleted successfully.");
        } catch (error) {
          console.error("Error deleting leave:", error);
          alert("Failed to delete leave. Please try again.");
        }
      };

      deleteLeave();
    }
  };

  return (
    <div className="container">
      <h1>Your Leave Records</h1>

      {error && <p className="error">Error: {error}</p>}

      {!leaves.length && !error && userId && <p>No leave records found for your account.</p>}

      <button className="apply-leave-button" onClick={handleNavigateToApplyLeave}>
        Apply for Leave
      </button>

      {leaves.length > 0 && (
        <table className="table">
          <thead>
            <tr>
              <th>Leave ID</th>
              <th>Employee ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Manager</th>
              <th>From Date</th>
              <th>To Date</th>
              <th>Total Days</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {leaves.map((leave) => (
              <tr key={leave.leaveId}>
                <td>{leave.leaveId}</td>
                <td>{leave.employeeId}</td>
                <td>{leave.name}</td>
                <td>{leave.email}</td>
                <td>{leave.manager}</td>
                <td>{new Date(leave.fromDate).toLocaleDateString()}</td>
                <td>{new Date(leave.toDate).toLocaleDateString()}</td>
                <td>{leave.totalLeaveDays}</td>
                <td>{leave.leaveReason}</td>
                <td className={getStatusColor(leave.leaveStatus)}>
                  {leave.leaveStatus}
                </td>
                <td>
                  {leave.leaveStatus === "Pending" ? (
                    <>
                      <Link to={`/editleave/${leave.leaveId}`}><button
                        className="edit-btn"
                      >
                        Edit
                      </button></Link>
                      <button
                        className="delete-btn"
                        onClick={() => handleDelete(leave.leaveId)}
                      >
                        Delete
                      </button>
                    </>
                  ) : (
                    <span>Actions disabled. Leave {leave.leaveStatus}.</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GetEmployeeLeaves;
