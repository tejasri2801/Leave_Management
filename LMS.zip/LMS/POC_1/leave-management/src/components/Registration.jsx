import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';
import { PostUser } from '../Services/HttpLeave';

function RegistrationPage() {
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleRegistration = async (event) => {
    event.preventDefault();
    setError('');

    try {
      const response = await PostUser(userName, email, password, role);

      if (response.status === 201) {
        const data = await response.json();
        alert(`Registration successful! Welcome, ${data.userName}`);
        navigate('/login');
      } else {
        setError('Registration failed. Please check your details.');
      }
    } catch (err) {
      setError('An error occurred during registration. Please try again later.');
    }
  };

  return (
    <div className="registration-container">
      <h2>Register</h2>
      <form onSubmit={handleRegistration} className="registration-form">
        <input
          type="text"
          placeholder="Username"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
          required
          className="registration-input"
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="registration-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="registration-input"
        />
        <select
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
          className="registration-dropdown"
        >
          <option value="Admin">Admin</option>
          <option value="Manager">Manager</option>
          <option value="Employee">Employee</option>
        </select>
        <button type="submit" className="registration-button">Register</button>
        {error && <p className="registration-error">{error}</p>}
      </form>
    </div>
  );
}

export default RegistrationPage;
