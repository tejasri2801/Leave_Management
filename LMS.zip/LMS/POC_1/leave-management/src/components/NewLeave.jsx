import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';
import { GetAllLeaves, PostLeave } from '../Services/HttpLeave';
import { useSelector } from 'react-redux';

function NewLeave() {
    const [formData, setFormData] = useState({
        employeeId: '',
        userId: '',        
        name: '',
        email: '',
        manager: '',
        fromDate: '',
        toDate: '',
        leaveReason: '',
    });

    const [totalLeaveDays, setTotalLeaveDays] = useState(0);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    //const userId = useSelector(state => state.auth.userId);
    const userId = localStorage.getItem("userId");

    useEffect(() => {
        const fetchLeaves = async () => {

            const response = await GetAllLeaves(userId);

            const data = await response.json();
            setExistingLeaves(data);
        };

        fetchLeaves();
    }, []);

    const [existingLeaves, setExistingLeaves] = useState([]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });

        if (name === 'fromDate' || name === 'toDate') {
            const fromDate = name === 'fromDate' ? new Date(value) : new Date(formData.fromDate);
            const toDate = name === 'toDate' ? new Date(value) : new Date(formData.toDate);

            if (fromDate && toDate && toDate >= fromDate) {
                const diffTime = Math.abs(toDate - fromDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                setTotalLeaveDays(diffDays);
            } else {
                setTotalLeaveDays(0);
            }
        }
    };


      const handleSubmit = async (e) => {
        e.preventDefault();
    
        const fromDate = new Date(formData.fromDate);
        const toDate = new Date(formData.toDate);
    
        const isOverlapping = existingLeaves.some(leave => {
            const existingFrom = new Date(leave.fromDate);
            const existingTo = new Date(leave.toDate);
            return (fromDate <= existingTo && toDate >= existingFrom); 
        });
    
        if (isOverlapping) {
            setError('Leave already applied for the selected date(s).');
            return;
        }
        const token = localStorage.getItem('authToken');
        //const userId = getUserIdFromToken(token); 
    
        if (!userId) {
            setError('Unable to retrieve userId from the token.');
            return;
        }
    
        const leaveData = {
            employeeId: formData.employeeId,
            userId: userId, 
            name: formData.name,
            email: formData.email,
            manager: formData.manager,
            fromDate: new Date(formData.fromDate).toISOString(),
            toDate: new Date(formData.toDate).toISOString(),
            totalLeaveDays: totalLeaveDays,
            leaveReason: formData.leaveReason, 
            leaveStatus: 'Pending',
        };
    
        try {
            const response = await PostLeave(leaveData);
    
            const responseData = await response.json();
            if (response.ok) {
                alert('Leave applied successfully!');
                navigate('/getempleaves');
            } else {
                console.log('Validation errors:', responseData.errors);
                setError(`Error applying for leave: ${responseData.errors ? JSON.stringify(responseData.errors) : 'Please try again.'}`);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error applying for leave. Please try again.');
        }
    };
    

    return (
        <div className="new-leave-container">
            <h2>Apply for Leave</h2>
            {error && <p className="error">{error}</p>}
            <form onSubmit={handleSubmit} className="new-leave-form">
                <div className="form-group">
                    <label>Employee ID</label>
                    <input
                        type="text"
                        name="employeeId"
                        value={formData.employeeId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>User ID</label>
                    <input
                        type="text"
                        name="userId"
                        value={formData.userId}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Manager</label>
                    <input
                        type="text"
                        name="manager"
                        value={formData.manager}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>From Date</label>
                    <input
                        type="date"
                        name="fromDate"
                        value={formData.fromDate}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>To Date</label>
                    <input
                        type="date"
                        name="toDate"
                        value={formData.toDate}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Leave Reason</label>
                    <textarea
                        name="leaveReason"
                        value={formData.leaveReason}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit">Apply Leave</button>
            </form>
        </div>
    );
}

export default NewLeave;
