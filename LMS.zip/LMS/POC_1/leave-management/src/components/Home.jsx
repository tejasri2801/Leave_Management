import React from 'react';
import '../App.css';
import { useSelector } from 'react-redux';

function HomePage() {

    const isLoggedIn = useSelector(state => state.auth.isLoggedIn);
  return (
    <div>
      <h1>Welcome to Leave Management System</h1>
      <p>{isLoggedIn ? 'Go to Dashboard for your records' : 'Click Login to Sign in to your Account'}</p> 
    </div>
  );
}

export default HomePage;