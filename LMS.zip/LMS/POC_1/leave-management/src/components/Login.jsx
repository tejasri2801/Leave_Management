import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import '../App.css';
import { useDispatch } from 'react-redux';
import { login, setIsLogin, setUserId } from '../store/ReduxSlice'
import { UserLogin } from '../Services/HttpLeave';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const handleLogin = async (event) => {
    event.preventDefault();
    setError('');

    try {
      const response = await UserLogin(email, password);

      if (response.ok) {
        const data = await response.json();
        const { token, userName, userRole, userId } = data;

        localStorage.setItem('authToken', token);
        localStorage.setItem('userName', userName);
        localStorage.setItem('userRole', userRole);
        localStorage.setItem('userId', userId);

        dispatch(setIsLogin());

        dispatch(login({ token }));

        dispatch(setUserId(userId));

        if (userRole === 'Employee') {
          navigate('/getempleaves');
        } else if (userRole === 'Manager') {
          navigate('/getmanleaves');
        } else {
          navigate('/');
        }
      } else {
        setError('Invalid email or password. Please try again.');
      }
    } catch (err) {
      setError('An error occurred. Please try again later.');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin} className="login-form">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="login-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="login-input"
        />
        <button type="submit" className="login-button">Login</button>
        {error && <p className="login-error">{error}</p>}
      </form>
      <p>Don't have an account? <Link to="/register">Register</Link></p>
    </div>
  );
}

export default LoginPage;
