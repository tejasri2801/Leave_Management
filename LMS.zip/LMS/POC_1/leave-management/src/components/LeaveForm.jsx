import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import "../App.css";
import { GetLeaveById, PutLeaveById, PostLeave, GetAllLeaves } from "../Services/HttpLeave";

const LeaveForm = ({ mode = "create" }) => {
  const [formData, setFormData] = useState({
    employeeId: "",
    userId: "",
    name: "",
    email: "",
    manager: "",
    fromDate: "",
    toDate: "",
    leaveReason: "",
  });

  const [totalLeaveDays, setTotalLeaveDays] = useState(0);
  const [error, setError] = useState("");
  const [existingLeaves, setExistingLeaves] = useState([]);
  const [isEditable, setIsEditable] = useState(true);
  const navigate = useNavigate();
  const params = useParams();
  const id = params.id;
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    const formatDate = (dateString) => {
      const date = new Date(dateString);
      return date.toLocaleDateString("en-CA");
    };

    const fetchExistingLeaves = async () => {
      const response = await GetAllLeaves(userId);
      const data = await response.json();
      setExistingLeaves(data);
    };

    const fetchLeaveById = async () => {
      const response = await GetLeaveById(id);
      const result = await response.json();

      setFormData({
        employeeId: result.employeeId,
        userId: result.userId,
        name: result.name,
        email: result.email,
        manager: result.manager,
        fromDate: formatDate(result.fromDate),
        toDate: formatDate(result.toDate),
        leaveReason: result.leaveReason,
      });

      setTotalLeaveDays(result.totalLeaveDays);
      if (result.leaveStatus === "Approved" || result.leaveStatus === "Rejected") {
        setIsEditable(false);
      }
    };

    if (mode === "edit") {
      fetchLeaveById();
    } else {
      fetchExistingLeaves();
    }
  }, [mode, id, userId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === "fromDate" || name === "toDate") {
      const fromDate = name === "fromDate" ? new Date(value) : new Date(formData.fromDate);
      const toDate = name === "toDate" ? new Date(value) : new Date(formData.toDate);

      if (fromDate && toDate && toDate >= fromDate) {
        const diffTime = Math.abs(toDate - fromDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        setTotalLeaveDays(diffDays);
      } else {
        setTotalLeaveDays(0);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const leaveData = {
      ...formData,
      userId: userId,
      totalLeaveDays,
      fromDate: new Date(formData.fromDate).toISOString(),
      toDate: new Date(formData.toDate).toISOString(),
    };

    try {
      if (mode === "edit") {
        if (!isEditable) {
          setError("This leave cannot be edited because it is already Approved or Rejected.");
          return;
        }

        const response = await PutLeaveById(id, leaveData);

        console.log(id);
        console.log(leaveData);
        console.log(response);



        if (!response.ok) {
          throw new Error("Failed to update leave.");
        }

        alert("Leave updated successfully.");
      } else {
        const fromDate = new Date(formData.fromDate);
        const toDate = new Date(formData.toDate);

        const isOverlapping = existingLeaves.some((leave) => {
          const existingFrom = new Date(leave.fromDate);
          const existingTo = new Date(leave.toDate);
          return fromDate <= existingTo && toDate >= existingFrom;
        });

        if (isOverlapping) {
          setError("Leave already applied for the selected date(s).");
          return;
        }

        const response = await PostLeave({ ...leaveData, leaveStatus: "Pending" });

        if (!response.ok) {
          throw new Error("Failed to apply for leave.");
        }

        alert("Leave applied successfully!");
      }

      navigate("/getempleaves");
    } catch (err) {
      setError(`Error: ${err.message}`);
    }
  };

  return (
    <div className="new-leave-container">
      <h1>{mode === "edit" ? "Edit Leave" : "Apply for Leave"}</h1>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit} className="new-leave-form">
        <div className="form-group">
          <label>Employee ID</label>
          <input type="text" name="employeeId" value={formData.employeeId} onChange={handleChange} required disabled={mode === "edit"} />
        </div>
        <div className="form-group">
          <label>User ID</label>
          <input type="text" name="userId" value={formData.userId} onChange={handleChange} required disabled={mode === "edit"} />
        </div>
        <div className="form-group">
          <label>Name</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required disabled={mode === "edit"} />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required disabled={mode === "edit"} />
        </div>
        <div className="form-group">
          <label>Manager</label>
          <input type="text" name="manager" value={formData.manager} onChange={handleChange} required disabled={mode === "edit"} />
        </div>
        <div className="form-group">
          <label>From Date</label>
          <input type="date" name="fromDate" value={formData.fromDate} onChange={handleChange} required disabled={mode === "edit" && !isEditable} />
        </div>
        <div className="form-group">
          <label>To Date</label>
          <input type="date" name="toDate" value={formData.toDate} onChange={handleChange} required disabled={mode === "edit" && !isEditable} />
        </div>
        <div className="form-group">
          <label>Leave Reason</label>
          <textarea name="leaveReason" value={formData.leaveReason} onChange={handleChange} required disabled={mode === "edit" && !isEditable} />
        </div>
        <div className="form-group">
          <label>Total Leave Days</label>
          <input type="number" value={totalLeaveDays} disabled />
        </div>
        <button type="submit">{mode === "edit" ? "Save Changes" : "Apply Leave"}</button>
      </form>
    </div>
  );
};

export default LeaveForm;
