﻿namespace Leave_Management_System.Models
{
    
        public class UpdateLeaveStatusRequest
        {
            public string Status { get; set; }
            public string Reason { get; set; }
        }

    
}
