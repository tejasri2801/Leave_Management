﻿using System.ComponentModel.DataAnnotations;

namespace Leave_Management_System.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public string UserName { get; set; } 
        public string Email { get; set; }
        public string Password { get; set; } 
        public string Role { get; set; } 
        
    } 
}
