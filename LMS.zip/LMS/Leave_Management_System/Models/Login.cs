﻿namespace Leave_Management_System.Models
{
    public class Login
    {
        public string UserEmail { get; set; }
        public string Password { get; set; }
    }
}
