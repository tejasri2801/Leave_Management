﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Leave_Management_System.Utility.SD;

namespace Leave_Management_System.Models
{
    public class Leave
    {
        [Key] 
        public int LeaveId { get; set; }
        public int EmployeeId { get; set; }
        public int? UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Manager { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int TotalLeaveDays { get; set; }
        public string LeaveReason { get; set; }
        public string LeaveStatus { get; set; } = "Pending";
       
    }
}
