﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Leave_Management_System.Data;
using Leave_Management_System.Models;
using Microsoft.AspNetCore.Authorization;
using static Leave_Management_System.Utility.SD;
using System.Security.Claims;

namespace Leave_Management_System.Controllers  
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize] 
    public class LeaveController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LeaveController(AppDbContext context) 
        {
            _context = context;
        }

        [Authorize(Roles = "Admin,Employee")]
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Leave>>> GetLeavesByUserId(int userId)
        {
            // Extract the UserId from the JWT token (claims)
            //var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier); // Assuming the UserId is stored in the "sub" claim
            //if (userIdClaim == null)
            //{
            //    return Unauthorized("User ID not found in the token.");
            //}

            //// Convert the UserId claim value to integer
            //if (!int.TryParse(userIdClaim.Value, out int userId))
            //{
            //    return BadRequest("Invalid User ID format.");
            //}

            // Get all leaves for the employee with the given userId
            var employeeLeaves = await _context.Leaves
                .Where(l => l.UserId == userId)  // Using UserId instead of empId
                .ToListAsync();

            if (employeeLeaves == null || !employeeLeaves.Any())
            {
                return NotFound($"No leaves found for user with ID {userId}");
            }

            return Ok(employeeLeaves);
        }

        [Authorize(Roles = "Admin,Employee")]
        [HttpGet("employee/{empId}")]
        public async Task<ActionResult<IEnumerable<Leave>>> GetLeavesByEmployeeId(int empId)
        {
            // Get all leaves for the employee with the given empId
            var employeeLeaves = await _context.Leaves
                .Where(l => l.EmployeeId == empId)
                .ToListAsync();

            if (employeeLeaves == null || !employeeLeaves.Any())
            {
                return NotFound($"No leaves found for employee with ID {empId}");
            }

            return Ok(employeeLeaves);
        }
        [Authorize(Roles ="Admin,Employee")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Leave>>> GetLeaves() 
        {
            return await _context.Leaves.ToListAsync();
        } 
        [Authorize(Roles ="Admin,Employee")] 
        [HttpGet("{id}")] 
        public async Task<ActionResult<Leave>> GetLeave(int id) 
        {
            var leave = await _context.Leaves.FindAsync(id);

            if (leave == null)
            {
                return NotFound();
            }

            return leave;
        }

        [Authorize(Roles = "Manager")]
        [HttpGet("manager/{managerName}")]
        public async Task<ActionResult<IEnumerable<Leave>>> GetManagerLeaves(string managerName)
        {
            // Retrieve all leaves where the manager matches the given manager name
            var managerLeaves = await _context.Leaves
                .Where(l => l.Manager == managerName && l.LeaveStatus == "Pending") // Filter pending leave requests
                .ToListAsync();

            if (managerLeaves == null || !managerLeaves.Any())
            {
                return NotFound($"No pending leaves found for manager {managerName}");
            }

            return Ok(managerLeaves);
        }

        [Authorize(Roles = "Employee")] 
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLeave(int id, Leave leave) 
        {
            if (id != leave.LeaveId)
            {
                return BadRequest();
            }

            _context.Entry(leave).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LeaveExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754 
        [Authorize(Roles ="Employee,Manager")] 
        [HttpPost]
        public async Task<ActionResult<Leave>> PostLeave(Leave leave)
        {
            // Calculate total days
            if (leave.FromDate > leave.ToDate)
            {
                return BadRequest("Start date cannot be later than end date.");
            }
            leave.TotalLeaveDays = (leave.ToDate - leave.FromDate).Days + 1;

            // Default leave status
            leave.LeaveStatus ="Pending";

            _context.Leaves.Add(leave);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLeave", new { id = leave.LeaveId }, leave);
        }

        [HttpPut("update-status/{id}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> UpdateLeaveStatus(int id, string status)
        {
            var leave = await _context.Leaves.FindAsync(id);
            if (leave == null)
            {
                return NotFound();
            }
            if (leave.LeaveStatus != "Pending")
            {
                return BadRequest("Leave status is not pending and cannot be updated.");
            } 
            // Update status
            leave.LeaveStatus = status;

            _context.Entry(leave).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LeaveExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [Authorize(Roles = "Employee,Admin")] 
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLeave(int id)
        {
            var leave = await _context.Leaves.FindAsync(id);
            if (leave == null)
            {
                return NotFound();
            }

            _context.Leaves.Remove(leave);
            await _context.SaveChangesAsync();  
           
            return NoContent();
        }

        private bool LeaveExists(int id)
        {
            return _context.Leaves.Any(e => e.LeaveId == id);
        }  
    }
}
