﻿namespace Leave_Management_System.Utility
{
    public class SD
    {
        public enum LeaveStatus
        {
            Pending,
            Approved,
            Rejected
        } 
    }
}
