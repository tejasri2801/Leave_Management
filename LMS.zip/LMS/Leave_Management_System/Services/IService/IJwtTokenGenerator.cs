﻿using Leave_Management_System.Models;

namespace Leave_Management_System.Services.IService
{
    public interface IJwtTokenGenerator
    {
        string GenerateToken(User user);
    }
}
