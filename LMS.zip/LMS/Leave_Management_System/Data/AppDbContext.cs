﻿using Leave_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Leave_Management_System.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Leave> Leaves { get; set; }
    }
}
